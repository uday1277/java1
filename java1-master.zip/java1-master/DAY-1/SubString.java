public class SubString
    {
     public static void main(String[] args)
     {
         String a = "shashi";
         String b = a.toUpperCase();
         String d = a.replace('h', 'k');
         System.out.println(a);
         System.out.println(b);
         System.out.println(d);
     }
    }

